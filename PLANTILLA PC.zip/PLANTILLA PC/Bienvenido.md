Esta es su nueva *bóveda*.

Cree una nota de algo, [[cree un enlace]], o pruebe [el Importador](https://help.obsidian.md/Plugins/Importer)!

Cuando esté listo, borre esta nota y aprópiese de la bóveda

---

Hola!!! soy Padu, quien configuró la aplicación, por favor referirse a [[Manual de uso]] 

---