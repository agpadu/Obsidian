Welcome to the official Obsidian Help site, where you can find tips and guides on how to use [Obsidian](https://obsidian.md/). For API documentation visit the [Obsidian Developer Docs](https://docs.obsidian.md/).

You can browse this site in several languages:

## Get started

Learn the basics of note-taking with Obsidian:

1. [Download and install Obsidian](https://help.obsidian.md/install)
2. [Create a vault](https://help.obsidian.md/vault)
3. [Create your first note](https://help.obsidian.md/create-note)
4. [Link notes](https://help.obsidian.md/link-notes)
5. [Import notes](https://help.obsidian.md/import)
6. [Sync your notes across devices](https://help.obsidian.md/sync-notes)

## Extend Obsidian

With thousands of plugins and themes, you can shape Obsidian to fit your way of thinking.

- [Core plugins](https://help.obsidian.md/plugins)
    - Choose which built-in features of Obsidian you want to turn on or off.
- [Community plugins](https://help.obsidian.md/community-plugins)
    - Enable more workflows and capabilities with features built by Obsidian users.
- [Themes](https://help.obsidian.md/themes)
    - Customize the look and feel of Obsidian with community-made color schemes.
- [CSS snippets](https://help.obsidian.md/snippets)
    - Make small changes to the interface on top of your Obsidian theme.
- [Web Clipper](https://help.obsidian.md/web-clipper)
    - Highlight web pages and save content to Obsidian using our browser extension.

## Add-on services

- [Obsidian Sync](https://help.obsidian.md/sync)
    - A safe and secure way to synchronize your notes across any device and OS.
- [Obsidian Publish](https://help.obsidian.md/publish)
    - Publish your notes as a wiki, knowledge base, documentation, or digital garden.

## Contribute

If you find any mistakes or missing information on this site, you can contribute improvements and translations via [the GitHub repo](https://github.com/obsidianmd/obsidian-docs/).

If you want to contribute to Obsidian financially, consider a [Catalyst license](https://help.obsidian.md/catalyst) which offers early access to beta versions, or a [Commercial license](https://help.obsidian.md/teams/license) to show your organization's support.

See the [Credits](https://help.obsidian.md/credits) to get to know all the amazing people who make Obsidian possible.