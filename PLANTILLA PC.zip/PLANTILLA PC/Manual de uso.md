
Para mayor comprensión activar el modo lector (clickear el librito)

---
# <u>ÍNDICE</u>
1. [[#<u>Funcionamiento básico</u>|Funcionamiento básico]]
2. [[#<u>Funcionamiento avanzado</u>|Funcionamiento avanzado]]
    - [[#Complementos nativos]]
    - [[#Complementos comunitarios]]

---
## <u>Funcionamiento básico</u>
 <b><font color="#7030a0">Obsidian</font></b> es una herramienta de tomado de notas simple y completa, que opera con archivos de tipo [Markdown](https://es.wikipedia.org/wiki/Markdown) que se almacenan en tu dispositivo, dentro de una carpeta determinada y designada.

> [!attention] Markdown
> a simples rasgos, es un tipo de archivo de texto simple, que gracias a la aplicación te permite visualizar una nota.

Esto mismo tiene ventajas, tales como:
1. **Peso ligero** 
    los archivos markdown son sustancialmente mas ligeros :LiDownload: y simples que uno .doc del tipo que maneja WORD
2. **Disponibilidad sin conexión**
    No dependes de un almacenamiento en la nube :LiCloudUpload:, en todo caso el mismo sería manual a modo de copias de seguridad


Para aprender mas sobre el funcionamiento de la aplicación, ventajas y desventajas véase: [Obsidian Help](https://help.obsidian.md/) o [Empieza aquí](https://publish.obsidian.md/help-es/Empieza+aqui)

---
## <u>Funcionamiento avanzado</u>
Como ya mencioné <b><font color="#7030a0">Obsidian</font></b> se caracteriza por ser una herramienta completa y simple, simple por su interfaz y completa por una gran característica <u><b>LOS COMPLEMENTOS</b></u>, estos mismos se podrían dividir en dos tipos:
- **[[#Complementos nativos|NATIVOS]]**
- **[[#Complementos comunitarios|COMUNITARIOS]]**

A continuación paso a dar una explicación breve y practica de los que están preinstalados y/o habilitados de ambos tipos

#### Complementos nativos
Al entrar en ajustes dentro de opciones, aparecen los **complementos principales** o **nativos**, por defecto dejo activado unos útiles indispensables, eres libre de activarlos y desactivarlos, los mismos no tienen mucho misterio.

#### Complementos comunitarios

> [!attention]- IMPORTANTE
> A continuación detallo los instalados desde el repositorio de complementos comunitarios oficial dentro de los ajustes. En el caso de importarse otros complementos desde plataformas como github, los mismos tienen una probabilidad de ser inseguros para tus notas. 

###### Editing toolbar
Cuando clickeas (derecho) tenés una barra de herramientas, a mi parecer la misma se encuentra incompleta, debido a compatibilidad del [markdown](https://es.wikipedia.org/wiki/Markdown) base, por lo que encontré este complemento que suma opciones, como el color del una palabra o texto particular, el subrayado, resaltado con colores personalizables, etc. 

En la configuración del plugin puedes quitar o sumar opciones, mientras puedan visualizarse el [[#Paleta de comandos|comando]]

###### File explorer ++
Herramienta que mejora la búsqueda de archivos

###### Force read mode
Hace que no puedas editar este archivo, para que la información no sea errónea o modificada (desinstalable o desactivable)

###### Highlightr
Herramienta especifica de <mark style="background: #BBFABBA6;">Resaltado</mark>, personalizable en sus ajustes

###### Iconize
Herramienta que permite el insertado de iconos con el prefijo ":"
<span style="background:rgba(240, 200, 0, 0.2)"> :"LiAlertTriangle": <b>es igual a</b> :LiAlertTriangle:</span>

###### Style settings
Permite configurar el tema de obsidian. El que estas viendo se llama <font color="#c0504d">PRISM</font>, hay otros disponibles pero en el uso yo encontré mas cómodo este.
###### Templater
Permite hacer y utilizar de manera mas cómodas <font color="#8064a2">plantillas</font> a partir de notas eso nada más. lo dejo instalado pero desactivado para que lo uses a criterio

---
# LISTOOOO
Eso es todo, es una herramienta que por mas qué este configurada es a criterio del usuario las distintas opciones y herramientas. Recomiendo que te tires una media hora chusmeando las opciones y seguro estas joya. 

>[!example]- Cualquier duda, consulta o sugerencia: [:LiMessageSquareMore: TELEGRAM](https://t.me/whoispadu)

---
#INFO #TUTORIAl

